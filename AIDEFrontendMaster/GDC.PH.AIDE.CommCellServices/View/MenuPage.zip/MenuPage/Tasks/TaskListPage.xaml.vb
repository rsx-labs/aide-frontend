﻿Imports UI_AIDE_CommCellServices.ServiceReference1
Imports System.Reflection
Imports System.IO
Imports System.Diagnostics
Imports System.ServiceModel
Imports System.Collections.ObjectModel
Imports System.Windows.Xps.Packaging
Imports System.Windows.Xps
Imports System.Printing

''' <summary>
''' By Aevan Camille Batongbacal
''' </summary>
''' <remarks></remarks>
<CallbackBehavior(ConcurrencyMode:=ConcurrencyMode.Single, UseSynchronizationContext:=False)>
Public Class TaskListPage
    Implements ServiceReference1.IAideServiceCallback


#Region "Fields"

    Private _AideService As ServiceReference1.AideServiceClient
    Private mainFrame As Frame
    Private isEmpty As Boolean
    Private email As String
    Dim lstTask As Task()

    Private Enum PagingMode
        _First = 1
        _Next = 2
        _Previous = 3
        _Last = 4
    End Enum

#End Region

#Region "Paging Declarations"
    Dim startRowIndex As Integer
    Dim lastRowIndex As Integer
    Dim pagingPageIndex As Integer
    Dim pagingRecordPerPage As Integer = 10
#End Region

#Region "Constructor"

    Public Sub New(mainFrame As Frame, _email As String)

        InitializeComponent()
        Me.email = _email
        Me.mainFrame = mainFrame
        SetData()
    End Sub

#End Region

#Region "Events"

    Private Sub lv_contacts_MouseDoubleClick(sender As Object, e As MouseButtonEventArgs) Handles lv_contacts.MouseDoubleClick
        e.Handled = True
        If lv_contacts.SelectedIndex <> -1 Then
            If lv_contacts.SelectedItem IsNot Nothing Then
                Dim _Email As String = CType(lv_contacts.SelectedItem, ContactListModel).EMAIL_ADDRESS
                If email = _Email Then
                    Dim contactList As New ContactListModel
                    contactList.EMP_ID = CType(lv_contacts.SelectedItem, ContactListModel).EMP_ID
                    contactList.EMAIL_ADDRESS = CType(lv_contacts.SelectedItem, ContactListModel).EMAIL_ADDRESS
                    contactList.EMAIL_ADDRESS2 = CType(lv_contacts.SelectedItem, ContactListModel).EMAIL_ADDRESS2
                    contactList.FIRST_NAME = CType(lv_contacts.SelectedItem, ContactListModel).FIRST_NAME
                    contactList.LAST_NAME = CType(lv_contacts.SelectedItem, ContactListModel).LAST_NAME
                    contactList.LOCAL = CType(lv_contacts.SelectedItem, ContactListModel).LOCAL
                    contactList.LOCATION = CType(lv_contacts.SelectedItem, ContactListModel).LOCATION
                    contactList.CEL_NO = CType(lv_contacts.SelectedItem, ContactListModel).CEL_NO
                    contactList.HOMEPHONE = CType(lv_contacts.SelectedItem, ContactListModel).HOMEPHONE
                    contactList.OTHER_PHONE = CType(lv_contacts.SelectedItem, ContactListModel).OTHER_PHONE

                    mainFrame.Navigate(New NewContactList(contactList, mainFrame, email))
                Else
                    Exit Sub
                End If
            End If
        End If
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As RoutedEventArgs) Handles btnPrint.Click
        Dim dialog As PrintDialog = New PrintDialog()
        If dialog.ShowDialog() = True Then
            dialog.PrintTicket.PageOrientation = PageOrientation.Landscape
            dialog.PrintVisual(lv_contacts, "My Canvas")
        End If
    End Sub
#End Region

#Region "Functions"

    Public Sub SetData()
        Try
            If InitializeService() Then
                lstTask = _AideService.ViewContactListAll(email)
                SetPaging(PagingMode._First)
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Public Sub LoadData()
        Try
            Dim lstContactsList As New ObservableCollection(Of ContactListModel)
            Dim contactListDBProvider As New ContactListDBProvider
            Dim contactListVM As New ContactListViewModel()

            Dim objContacts As New ContactList()

            For i As Integer = startRowIndex To lastRowIndex
                objContacts = lstContacts(i)
                contactListDBProvider.SetMyContactList(objContacts)
            Next

            For Each rawUser As MyContactList In contactListDBProvider.GetMyContactList()
                lstContactsList.Add(New ContactListModel(rawUser))
            Next

            contactListVM.ContactList = lstContactsList
            Me.DataContext = contactListVM
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "FAILED")
        End Try
    End Sub

    Public Sub LoadData()
        Try
            Dim lstTaskList As New ObservableCollection(Of TasksModel)
            Dim tasksListDBProvider As New TaskDBProvider
            Dim taskListVM As New TasksViewModel()

            Dim objTasks As New Tasks()

            For i As Integer = startRowIndex To lastRowIndex
                objContacts = lstTask(i)
                tasksListDBProvider.SetTaskList(objTasks)
            Next

            For Each rawUser As MyTasks In tasksListDBProvider.GetTaskList()
                lstTaskList.Add(New TasksModel(rawUser))
            Next

            taskListVM.TaskList = lstTaskList
            Me.DataContext = taskListVM
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "FAILED")
        End Try
    End Sub

    Public Function InitializeService() As Boolean
        Dim bInitialize As Boolean = False
        Try
            Dim Context As InstanceContext = New InstanceContext(Me)
            _AideService = New AideServiceClient(Context)
            _AideService.Open()
            bInitialize = True
        Catch ex As SystemException
            _AideService.Abort()
        End Try
        Return bInitialize
    End Function

    Private Sub SetPaging(mode As Integer)
        Try
            Dim totalRecords As Integer = lstTask.Length

            Select Case mode
                Case CInt(PagingMode._Next)
                    ' Set the rows to be displayed if the total records is more than the (Record per Page * Page Index)
                    If totalRecords > (pagingPageIndex * pagingRecordPerPage) Then

                        ' Set the last row to be displayed if the total records is more than the (Record per Page * Page Index) + Record per Page
                        If totalRecords >= ((pagingPageIndex * pagingRecordPerPage) + pagingRecordPerPage) Then
                            lastRowIndex = ((pagingPageIndex * pagingRecordPerPage) + pagingRecordPerPage) - 1
                        Else
                            lastRowIndex = totalRecords - 1
                        End If

                        startRowIndex = pagingPageIndex * pagingRecordPerPage
                        pagingPageIndex += 1
                    Else
                        startRowIndex = (pagingPageIndex - 1) * pagingRecordPerPage
                        lastRowIndex = totalRecords - 1
                    End If
                    ' Bind data to the Data Grid
                    LoadData()
                    Exit Select
                Case CInt(PagingMode._Previous)
                    ' Set the Previous Page if the page index is greater than 1
                    If pagingPageIndex > 1 Then
                        pagingPageIndex -= 1

                        startRowIndex = ((pagingPageIndex * pagingRecordPerPage) - pagingRecordPerPage)
                        lastRowIndex = (pagingPageIndex * pagingRecordPerPage) - 1
                        LoadData()
                    End If
                    Exit Select
                Case CInt(PagingMode._First)
                    If totalRecords > pagingRecordPerPage Then
                        pagingPageIndex = 2
                        SetPaging(CInt(PagingMode._Previous))
                    Else
                        pagingPageIndex = 1
                        startRowIndex = ((pagingPageIndex * pagingRecordPerPage) - pagingRecordPerPage)

                        If Not totalRecords = 0 Then
                            lastRowIndex = totalRecords - 1
                            LoadData()
                        Else
                            lastRowIndex = 0
                            Me.DataContext = Nothing
                        End If

                    End If
                    Exit Select
                Case CInt(PagingMode._Last)
                    pagingPageIndex = (lstTask.Length / pagingRecordPerPage)
                    SetPaging(CInt(PagingMode._Next))
                    Exit Select
            End Select

            DisplayPagingInfo()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "FAILED")
        End Try
    End Sub

    Private Sub DisplayPagingInfo()
        Dim pagingInfo As String

        ' If there has no data found
        If lstTask.Length = 0 Then
            pagingInfo = "No Results Found "
            GUISettingsOff()
        Else
            pagingInfo = "Displaying " & startRowIndex + 1 & " to " & lastRowIndex + 1
            GUISettingsOn()
        End If

        lblPagingInfo.Content = pagingInfo
        lblPageNo.Content = pagingPageIndex
    End Sub

    Private Sub GUISettingsOff()
        lv_contacts.Visibility = Windows.Visibility.Hidden
        btnFirst.IsEnabled = False
        btnLast.IsEnabled = False
        btnPrev.IsEnabled = False
        btnNext.IsEnabled = False
    End Sub

    Private Sub GUISettingsOn()
        lv_contacts.Visibility = Windows.Visibility.Visible
        btnFirst.IsEnabled = True
        btnLast.IsEnabled = True
        btnPrev.IsEnabled = True
        btnNext.IsEnabled = True
    End Sub

    Private Sub btnNext_Click(sender As Object, e As RoutedEventArgs)
        SetPaging(CInt(PagingMode._Next))
    End Sub

    Private Sub btnPrev_Click(sender As Object, e As RoutedEventArgs)
        SetPaging(CInt(PagingMode._Previous))
    End Sub

    Private Sub btnFirst_Click(sender As Object, e As RoutedEventArgs)
        SetPaging(CInt(PagingMode._First))
    End Sub

    Private Sub btnLast_Click(sender As Object, e As RoutedEventArgs)
        SetPaging(CInt(PagingMode._Last))
    End Sub
#End Region

#Region "ICallBack Function"
    Public Sub NotifyError(message As String) Implements IAideServiceCallback.NotifyError
        If message <> String.Empty Then
            MessageBox.Show(message)
        End If
    End Sub

    Public Sub NotifyOffline(EmployeeName As String) Implements IAideServiceCallback.NotifyOffline

    End Sub

    Public Sub NotifyPresent(EmployeeName As String) Implements IAideServiceCallback.NotifyPresent

    End Sub

    Public Sub NotifySuccess(message As String) Implements IAideServiceCallback.NotifySuccess
        If message <> String.Empty Then
            MessageBox.Show(message)
        End If
    End Sub

    Public Sub NotifyUpdate(objData As Object) Implements IAideServiceCallback.NotifyUpdate

    End Sub
#End Region
End Class
