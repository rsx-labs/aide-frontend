﻿Imports System.Data
Imports UI_AIDE_CommCellServices.ServiceReference1
Imports System.ServiceModel
Imports System.Collections.ObjectModel

''' <summary>
''' By Jester Sanchez/ Lemuela Abulencia
''' </summary>
''' <remarks></remarks>
Class UpdateActionListPage
    Implements UI_AIDE_CommCellServices.ServiceReference1.IAideServiceCallback

#Region "Page Declaration"
    Private _frame As Frame
    Private aide As AideServiceClient
    Private action_provider As New ActionListDBProvider
    Private actionPage_ As HomeActionListsPage
    Private act_ion As New Action
    Private _actionModel As New ActionModel()
    Private _email As String
    Private hold_Duedate As String
#End Region

    Public Sub New(f As Frame, act_ As Action, email As String)
        Try
            _email = email
            _frame = f
            act_ion = act_

            InitializeComponent()
            DataContext = _actionModel
            showUpdateItems()
            PopulateComboBox()
            hold_Duedate = _actionModel.DUE_DATE
        Catch ex As Exception
            If MsgBox(ex.Message + " Do you wish to exit?", vbYesNo + vbCritical, "Error Encountered") = vbYes Then
                Environment.Exit(0)
            Else
            End If
        End Try
    End Sub
#Region "Main Function/Method"

    Public Function showUpdateItems()
        Try
            InitializeService()
            _actionModel.REF_NO = act_ion.Act_ID
            _actionModel.ACTION_MESSAGE = act_ion.Act_Message
            _actionModel.EMP_ID = act_ion.Act_Assignee
            _actionModel.NICK_NAME = act_ion.Act_NickName
            _actionModel.DUE_DATE = act_ion.Act_DueDate
            _actionModel.DATE_CLOSED = act_ion.Act_DateClosed
            Return _actionModel
        Catch ex As Exception
            If MsgBox(ex.Message + " Do you wish to exit?", vbYesNo + vbCritical, "Error Encountered") = vbYes Then
                Environment.Exit(0)
            End If
            Return ex
        End Try
    End Function

    Public Function getDataUpdate(ByVal ActionModel As ActionModel)
        Try
            InitializeService()
            If ActionModel.REF_NO = Nothing Or ActionModel.ACTION_MESSAGE = Nothing Or Act_AssigneeCB2.SelectedValue = Nothing Or ActionModel.DUE_DATE = Nothing Or ActionModel.DATE_CLOSED = Nothing Then
                act_ion.Act_ID = ActionModel.REF_NO
                act_ion.Act_Message = ActionModel.ACTION_MESSAGE
                act_ion.Act_Assignee = Act_AssigneeCB2.SelectedValue
                act_ion.Act_DueDate = ActionModel.DUE_DATE
                act_ion.Act_DateClosed = ActionModel.DATE_CLOSED
                act_ion.Act_NickName = String.Empty
            Else
                act_ion.Act_ID = ActionModel.REF_NO
                act_ion.Act_Message = ActionModel.ACTION_MESSAGE
                act_ion.Act_Assignee = Act_AssigneeCB2.SelectedValue
                act_ion.Act_DueDate = ActionModel.DUE_DATE
                act_ion.Act_DateClosed = ActionModel.DATE_CLOSED
                act_ion.Act_NickName = String.Empty
            End If
            Return act_ion
        Catch ex As Exception
            If MsgBox(ex.Message + " Do you wish to exit?", vbYesNo + vbCritical, "Error Encountered") = vbYes Then
                Environment.Exit(0)
            End If
            Return ex
        End Try
    End Function

    Public Sub PopulateComboBox()
        Try
            If InitializeService() Then
                Dim lstNickname As Nickname() = aide.ViewNicknameByDeptID(_email)
                Dim lstNicknameList As New ObservableCollection(Of NicknameModel)
                Dim successRegisterDBProvider As New SuccessRegisterDBProvider
                Dim nicknameVM As New NicknameViewModel()

                For Each objLessonLearnt As Nickname In lstNickname
                    successRegisterDBProvider.SetMyNickname(objLessonLearnt)
                Next

                For Each rawUser As MyNickname In successRegisterDBProvider.GetMyNickname()
                    lstNicknameList.Add(New NicknameModel(rawUser))
                Next

                nicknameVM.NicknameList = lstNicknameList
                Act_AssigneeCB2.DataContext = nicknameVM

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

#End Region

#Region "Services Function/Method"

    Public Function InitializeService() As Boolean
        Dim bInitialize As Boolean = False
        Try
            Dim Context As InstanceContext = New InstanceContext(Me)
            aide = New AideServiceClient(Context)
            aide.Open()
            bInitialize = True
        Catch ex As SystemException
            aide.Abort()
        End Try
        Return bInitialize
    End Function

    Public Sub NotifyError(message As String) Implements IAideServiceCallback.NotifyError

    End Sub

    Public Sub NotifyOffline(EmployeeName As String) Implements IAideServiceCallback.NotifyOffline

    End Sub

    Public Sub NotifyPresent(EmployeeName As String) Implements IAideServiceCallback.NotifyPresent

    End Sub

    Public Sub NotifySuccess(message As String) Implements IAideServiceCallback.NotifySuccess

    End Sub

    Public Sub NotifyUpdate(objData As Object) Implements IAideServiceCallback.NotifyUpdate

    End Sub

#End Region

#Region "Events Trigger"

    Private Sub UpdateBtn_Click(sender As Object, e As RoutedEventArgs)
        Try
            InitializeService()
            If _actionModel.REF_NO = Nothing Or _actionModel.ACTION_MESSAGE = Nothing Or Act_AssigneeCB2.SelectedValue = Nothing Or _actionModel.DUE_DATE = Nothing Or _actionModel.DATE_CLOSED = Nothing Then
                If _actionModel.DATE_CLOSED = Nothing And _actionModel.ACTION_MESSAGE <> Nothing And _actionModel.DUE_DATE <> Nothing And Act_AssigneeCB2.SelectedValue <> Nothing Then
                    If MsgBox("Do you want to proceed without closing date?", MsgBoxStyle.Information + vbYesNo, "Update") = vbYes Then
                        aide.UpdateActionList(getDataUpdate(Me.DataContext()))
                        MsgBox("Successfully Updated!", vbOKOnly + MsgBoxStyle.Information, "Success")
                        act_ion.Act_ID = Nothing
                        act_ion.Act_Message = Nothing
                        act_ion.Act_Assignee = Nothing
                        act_ion.Act_DueDate = Nothing
                        act_ion.Act_DateClosed = Nothing
                    End If
                Else
                    MsgBox("Please fill up all fields!", vbOKOnly + MsgBoxStyle.Information, "Empty")
                End If
            Else
                aide.UpdateActionList(getDataUpdate(Me.DataContext()))
                MsgBox("Successfully Updated!", vbOKOnly + MsgBoxStyle.Information, "Success")
                act_ion.Act_ID = Nothing
                act_ion.Act_Message = Nothing
                act_ion.Act_Assignee = Nothing
                act_ion.Act_DueDate = Nothing
                act_ion.Act_DateClosed = Nothing
            End If
        Catch ex As Exception
            If MsgBox(ex.Message + " Do you wish to exit?", vbYesNo + vbCritical, "Error Encountered") = vbYes Then
                Environment.Exit(0)
            End If
        End Try
    End Sub

    Private Sub BackBtn_Click(sender As Object, e As RoutedEventArgs)
        _frame.Navigate(New HomeActionListsPage(_frame, _email))
    End Sub

    'Validates if selected duedate is less than the previous due date
    Private Sub Act_DueDate_SelectedDateChanged(sender As Object, e As SelectionChangedEventArgs)
        If Act_DueDate.SelectedDate < hold_Duedate Then
            MsgBox("Dates Should be not the Day Before!", MsgBoxStyle.Critical, "Employee Assist Tools")

            Act_DueDate.Text = hold_Duedate
        End If
        If Act_DueDate.Text = String.Empty Then
            Act_DueDate.Text = _actionModel.DUE_DATE
        End If
    End Sub

    'Validate if selected date is less than duedate
    Private Sub Act_DateClosed_SelectedDateChanged(sender As Object, e As SelectionChangedEventArgs)
        If Act_DateClosed.SelectedDate < Act_DueDate.SelectedDate Then
            MsgBox("Date Should be not the Day Before Selected From Date!", MsgBoxStyle.Critical, "Employee Assist Tools")

            Act_DateClosed.Text = String.Empty
        End If

        If Act_DateClosed.Text = String.Empty Then
            Act_DateClosed.Text = _actionModel.DATE_CLOSED
        End If
    End Sub

#End Region

End Class
